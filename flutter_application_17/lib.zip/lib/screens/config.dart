import 'package:flutter_application_17/screens/doctors.dart';
import 'package:flutter_application_17/screens/patients.dart';

class Configure{
  static const server = "192.168.1.56:3000";
  static Users login = Users();
  static Patients data = Patients();
}