import 'package:flutter/material.dart';
import 'package:flutter_application_17/screens/config.dart';
import 'package:flutter_application_17/screens/create.dart';
//import 'package:flutter_application_17/screens/doctors.dart';
import 'package:flutter_application_17/screens/home.dart';
import 'package:flutter_application_17/screens/patients.dart';
import 'package:http/http.dart' as http;

class Data extends StatelessWidget {
  const Data({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(home: PatientsScreen());
  }
}

class PatientsScreen extends StatefulWidget {
  const PatientsScreen({Key? key}) : super(key: key);

  @override
  _PatientsScreenState createState() => _PatientsScreenState();
}

class _PatientsScreenState extends State<PatientsScreen> {
  List<Patients> _patientsList = [];

  Widget mainBody = Container();

  @override
  void initState() {
    super.initState();
    Patients data = Configure.data;
    if (data.id != null) {
      getData();
    }
  }

  Future<void> getData() async {
    var url = Uri.https(Configure.server, "patients");
    var resp = await http.get(url);

    setState(() {
      _patientsList = patientsFromJson(resp.body);
      mainBody = showPatients();
    });
    return;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Align(
          alignment: Alignment.center,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              SizedBox(
                height: 50.0,
              ),
              Text(
                "ข้อมูลผู้ป่วย",
                style: TextStyle(fontSize: 24),
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: Padding(
        padding: const EdgeInsets.symmetric(
          vertical: 50.0,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              width: 150,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => Home()),
                  );
                },
                style: ElevatedButton.styleFrom(
                    primary: Color.fromARGB(255, 140, 219, 231)),
                child: Text(
                  'ย้อนกลับ',
                  style: TextStyle(color: Color.fromARGB(255, 0, 3, 4)),
                ),
              ),
            ),
            SizedBox(width: 20),
            SizedBox(
              width: 150,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => Create()),
                  );
                  // ตรงนี้คุณสามารถเรียกหน้าที่เกี่ยวข้องกับการเพิ่มข้อมูลผู้ป่วย
                },
                style: ElevatedButton.styleFrom(
                    primary: Color.fromARGB(255, 140, 219, 231)),
                child: Text(
                  'เพิ่มข้อมูลผู้ป่วยใหม่',
                  style: TextStyle(color: Color.fromARGB(255, 0, 3, 4)),
                ),
              ),
            ),
          ],
        ),
      ),
      // body: mainBody, // แสดงรายการผู้ป่วยที่โหลดมา
    );
  }

  Widget showPatients() {
    return ListView.builder(
      itemCount: _patientsList.length,
      itemBuilder: (context, index) {
        //Patients patient = _patientsList[index];
        return ListTile(
          title: Text("line"), // แสดงชื่อของผู้ป่วย
        );
      },
    );
  }
}
