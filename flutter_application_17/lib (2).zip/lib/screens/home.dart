import 'package:flutter/material.dart';
import 'package:flutter_application_17/screens/data.dart';

class Home extends StatefulWidget {
  static const routeName = '/home';
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  
  Widget mainBody = Container();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Container(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Patients Information Management System',
                style: TextStyle(
                  fontSize: 20, // ปรับขนาดตัวอักษรตามความเหมาะสม
                  fontWeight: FontWeight.bold, // กำหนดความหนาของตัวอักษร
                ),
              ),
              Container(
                margin: const EdgeInsets.all(50),
                // เพิ่มเนื้อหาหรือวิดเจ็ตอื่น ๆ ของหน้านี้ที่นี่
              ),
            ],
              
          ),
        ),
      ),
      floatingActionButton: ElevatedButton(
        onPressed: () {
          // ใส่โค้ดที่คุณต้องการให้ทำงานเมื่อปุ่มถูกกด
          Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => Data()),
    );
        },
        
        child: Text('ปุ่มถัดไป'),
      ),
    );
  }
}


